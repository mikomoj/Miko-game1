#include <SFML/Graphics.hpp>
#include <iostream>
#include <optional>
#include <cstdint> // std::uint8_t के लिए जरूरी है

// गेम की अलग-अलग स्क्रीन तय करने के लिए
enum class GameState {
    SplashScreen,
    MainMenu
};

int main() {
    sf::RenderWindow window(sf::VideoMode({800, 600}), "Minecraft Main Menu");
    window.setFramerateLimit(60);

    sf::Font font;
    if (!font.openFromFile("arial.ttf")) {
        std::cout << "Error: arial.ttf file not found!" << std::endl;
        return -1;
    }

    // --- 1. स्प्लैश स्क्रीन की चीजें ---
    sf::Text mojangText(font, "MOJANG", 60);
    mojangText.setFillColor(sf::Color::White);
    mojangText.setPosition({260, 220});

    sf::RectangleShape loadingBar({0, 20});
    loadingBar.setFillColor(sf::Color::White);
    loadingBar.setPosition({150, 400});

    // फेड इफ़ेक्ट के लिए एक काला पर्दा (Overlay)
    sf::RectangleShape fadeScreen({800, 600});
    fadeScreen.setFillColor(sf::Color(0, 0, 0, 0)); // शुरुआत में पूरी तरह पारदर्शी

    float progress = 0.0f;
    int fadeAlpha = 0;          // काले पर्दे का धुंधलापन (0 से 255)
    bool isFadingOut = false;   // क्या फेड आउट शुरू करना है?

    // --- 2. मेन मेन्यू (Main Menu) की चीजें ---
    sf::Text gameTitle(font, "MINECRAFT", 70);
    gameTitle.setFillColor(sf::Color::Yellow); // माइनक्राफ्ट जैसा पीला रंग
    gameTitle.setPosition({210, 100});

    // Single Player बटन का बैकग्राउंड और टेक्स्ट
    sf::RectangleShape singlePlayerBtn({400, 40});
    singlePlayerBtn.setFillColor(sf::Color(100, 100, 100)); // ग्रे रंग
    singlePlayerBtn.setPosition({200, 280});
    sf::Text singlePlayerText(font, "Single Player", 20);
    singlePlayerText.setFillColor(sf::Color::White);
    singlePlayerText.setPosition({335, 288});

    // Multiplayer बटन का बैकग्राउंड और टेक्स्ट
    sf::RectangleShape multiPlayerBtn({400, 40});
    multiPlayerBtn.setFillColor(sf::Color(100, 100, 100));
    multiPlayerBtn.setPosition({200, 340});
    sf::Text multiPlayerText(font, "Multiplayer", 20);
    multiPlayerText.setFillColor(sf::Color::White);
    multiPlayerText.setPosition({345, 348});

    // गेम की शुरुआती स्टेट स्प्लैश स्क्रीन होगी
    GameState currentState = GameState::SplashScreen;

    // मुख्य लूप
    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
        }

        // --- गेम का लॉजिक (Logic) ---
        if (currentState == GameState::SplashScreen) {
            // लोडिंग बार बढ़ाना
            if (progress < 500.0f) {
                progress += 4.0f; 
                loadingBar.setSize({progress, 20});
            } else {
                isFadingOut = true;
            }

            if (isFadingOut) {
                fadeAlpha += 5; // पर्दे को धीरे-धीरे काला करना
                if (fadeAlpha >= 255) {
                    fadeAlpha = 255;
                    currentState = GameState::MainMenu; // स्क्रीन बदल कर मेन्यू कर दो
                }
                // यहाँ sf::Uint8 की जगह std::uint8_t कर दिया है
                fadeScreen.setFillColor(sf::Color(0, 0, 0, static_cast<std::uint8_t>(fadeAlpha)));
            }
        } 
        else if (currentState == GameState::MainMenu) {
            // मेन्यू स्क्रीन पर आने के बाद काले पर्दे को धीरे-धीरे हटाना (Fade-In)
            if (fadeAlpha > 0) {
                fadeAlpha -= 5;
                // यहाँ भी sf::Uint8 की जगह std::uint8_t कर दिया है
                fadeScreen.setFillColor(sf::Color(0, 0, 0, static_cast<std::uint8_t>(fadeAlpha)));
            }
        }

        // --- स्क्रीन पर रेंडर करना (Drawing) ---
        window.clear();

        if (currentState == GameState::SplashScreen) {
            window.clear(sf::Color::Red); // स्प्लैश स्क्रीन का बैकग्राउंड लाल
            window.draw(mojangText);
            window.draw(loadingBar);
            if (isFadingOut) window.draw(fadeScreen); 
        } 
        else if (currentState == GameState::MainMenu) {
            window.clear(sf::Color(30, 30, 30)); // मेन्यू का बैकग्राउंड डार्क ग्रे
            
            window.draw(gameTitle);
            window.draw(singlePlayerBtn);
            window.draw(singlePlayerText);
            window.draw(multiPlayerBtn);
            window.draw(multiPlayerText);
            
            if (fadeAlpha > 0) window.draw(fadeScreen); 
        }

        window.display();
    }

    return 0;
}
